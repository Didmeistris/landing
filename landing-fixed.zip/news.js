const box = document.getElementById('news-container');
const status = document.getElementById('news-status');
const refresh = document.getElementById('news-refresh');
let data = null;
let currentTab = 'all';
let pending = false;
const date = value => value && Number.isFinite(Date.parse(value))
  ? new Date(value).toLocaleString('ru-RU', { timeZone: 'Europe/Moscow', dateStyle: 'medium', timeStyle: 'short' }) : null;
function element(tag, className, text) {
  const node = document.createElement(tag);
  node.className = className;
  if (text) node.textContent = text;
  return node;
}
export function validItem(item, sources) {
  try {
    const link = new URL(item.link);
    const origin = new URL(sources[item.source].url);
    return link.protocol === 'https:' && link.hostname === origin.hostname && typeof item.title === 'string' && item.title.trim().length > 5;
  } catch { return false; }
}
function render() {
  box.replaceChildren();
  if (!data) return;
  const sources = Object.entries(data.sources).filter(([key]) => currentTab === 'all' || key === currentTab);
  for (const [key, source] of sources) {
    const items = data.items.filter(item => item.source === key && validItem(item, data.sources)).slice(0, currentTab === 'all' ? 3 : 6);
    if (source.status !== 'ok' || !items.length) {
      const warning = element('div', 'news-loader', `${source.label}: ${items.length ? 'источник недоступен. Показаны сохранённые публикации.' : 'публикации пока недоступны.'}${date(source.updatedAt) ? ' Последняя успешная проверка: ' + date(source.updatedAt) + ' (МСК).' : ''} `);
      warning.style.gridColumn = '1 / -1';
      const link = element('a', 'nc-read', 'Открыть официальный источник →');
      link.href = source.url; link.target = '_blank'; link.rel = 'noopener noreferrer';
      warning.append(link); box.append(warning);
    }
    for (const item of items) {
      const card = element('a', 'news-card');
      card.href = item.link; card.target = '_blank'; card.rel = 'noopener noreferrer';
      const meta = element('div', 'news-card-meta');
      meta.append(element('span', 'news-source-badge ns-' + key, source.label));
      meta.append(element('span', 'nc-date', item.date ? date(item.date)?.split(',')[0] || 'Дата не указана' : 'Дата не указана источником'));
      card.append(meta, element('h4', 'nc-title', item.title));
      if (item.desc) card.append(element('p', 'nc-desc', item.desc));
      card.append(element('span', 'nc-read', 'Читать →')); box.append(card);
    }
  }
}
window.showNewsTab = tab => {
  if (!['all', 'cz', 'teksher'].includes(tab)) return;
  currentTab = tab;
  document.querySelectorAll('.news-tab-btn').forEach(button => {
    const selected = button.id === 'ntab-' + tab;
    button.classList.toggle('active-ntab', selected);
    button.setAttribute('aria-pressed', String(selected));
  });
  render();
};
window.loadAllNews = async () => {
  if (pending || !box) return;
  pending = true; refresh.disabled = true; box.setAttribute('aria-busy', 'true');
  status.textContent = 'Проверяем обновления…';
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 10000);
    let response;
    try { response = await fetch(new URL('./news.json', document.baseURI), { cache: 'no-store', signal: controller.signal }); }
    finally { clearTimeout(timer); }
    if (!response.ok) throw new Error('News unavailable');
    const next = await response.json();
    if (!Array.isArray(next.items) || !next.sources || !date(next.checkedAt) || !['cz', 'teksher'].every(key => next.sources[key] && validSource(next.sources[key], key))) throw new Error('Invalid news data');
    data = next; render();
    const old = Date.now() - Date.parse(data.checkedAt) > 3 * 60 * 60 * 1000;
    status.textContent = `${old ? 'Данные давно не обновлялись. ' : ''}Проверка источников: ${date(data.checkedAt)} (МСК).${Object.values(data.sources).some(s => s.status !== 'ok') ? ' Есть недоступные источники.' : ''}`;
  } catch {
    status.textContent = 'Не удалось получить обновления. ' + (data ? 'Показаны ранее загруженные публикации.' : 'Попробуйте позже или откройте официальные источники.');
    if (!data) { box.replaceChildren(element('div', 'news-loader', 'Новости временно недоступны.')); }
  } finally { pending = false; refresh.disabled = false; box.setAttribute('aria-busy', 'false'); }
};
function validSource(source, key) {
  try { return new URL(source.url).hostname === (key === 'cz' ? 'xn--80ajghhoc2aj1c8b.xn--p1ai' : 'main.teksher.kg') && new URL(source.url).protocol === 'https:'; } catch { return false; }
}
if (box) {
  window.loadAllNews();
  setInterval(() => { if (!document.hidden) window.loadAllNews(); }, 600000);
}
